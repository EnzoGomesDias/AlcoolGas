
public class AlcoolGas {
public static void main(String[] args){
	double alcool = 2.39;
	double gas = 3.19;
	
	if(gas*0.7>alcool) {System.out.println("Coloque Alcool");}
	if(gas*0.7<alcool) {System.out.println("Coloque Gasolina");}
	
	}
}

